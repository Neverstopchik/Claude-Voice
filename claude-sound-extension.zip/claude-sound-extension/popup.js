const fileInput = document.getElementById('fileInput');
const statusEl = document.getElementById('status');
const previewAudio = document.getElementById('previewAudio');
const previewBtn = document.getElementById('previewBtn');
const resetBtn = document.getElementById('resetBtn');

function setStatus(text) {
  statusEl.textContent = text;
}

function refreshCurrentInfo() {
  chrome.storage.local.get(['customSoundDataUrl', 'customSoundName'], (res) => {
    if (res.customSoundDataUrl) {
      setStatus('Текущий звук: ' + (res.customSoundName || 'свой файл'));
      previewAudio.src = res.customSoundDataUrl;
    } else {
      setStatus('Сейчас используется встроенный бип');
      previewAudio.removeAttribute('src');
    }
  });
}

fileInput.addEventListener('change', () => {
  const file = fileInput.files[0];
  if (!file) return;

  if (file.size > 3 * 1024 * 1024) {
    setStatus('Файл слишком большой (макс. 3 МБ)');
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    chrome.storage.local.set(
      { customSoundDataUrl: dataUrl, customSoundName: file.name },
      () => {
        setStatus('Сохранено: ' + file.name);
        previewAudio.src = dataUrl;
      }
    );
  };
  reader.readAsDataURL(file);
});

previewBtn.addEventListener('click', () => {
  if (previewAudio.src) {
    previewAudio.currentTime = 0;
    previewAudio.play();
  } else {
    setStatus('Сначала выбери файл');
  }
});

resetBtn.addEventListener('click', () => {
  chrome.storage.local.remove(['customSoundDataUrl', 'customSoundName'], () => {
    setStatus('Сброшено на встроенный бип');
    previewAudio.removeAttribute('src');
  });
});

const copyBtn = document.getElementById('copyBtn');
copyBtn.addEventListener('click', () => {
  const addr = document.getElementById('addr').textContent;
  navigator.clipboard.writeText(addr).then(() => {
    copyBtn.textContent = 'Скопировано ✓';
    setTimeout(() => { copyBtn.textContent = 'Скопировать адрес'; }, 1500);
  });
});

refreshCurrentInfo();
