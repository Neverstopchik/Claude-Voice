// Claude.ai — звук по завершении генерации (v4: + свой звук через popup)
//
// 1) Перехватываем fetch-стрим ответа модели, ждём его реального завершения (done: true).
// 2) Звук: если пользователь выбрал свой файл в попапе — декодируем его через
//    AudioContext.decodeAudioData и проигрываем через AudioBufferSourceNode.
//    Это НЕ проходит через CSP media-src (в отличие от <audio src="...">), потому что
//    decodeAudioData работает с уже полученными байтами, а не загружает ресурс по URL.
//    Если своего звука нет — синтезируем встроенный бип осциллятором (тоже мимо CSP).

(function () {
  'use strict';

  let audioCtx = null;
  let customBuffer = null; // decoded AudioBuffer пользовательского звука

  function getCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function base64ToArrayBuffer(dataUrl) {
    const base64 = dataUrl.split(',').pop();
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  function setCustomSound(dataUrl) {
    customBuffer = null;
    if (!dataUrl) return;
    try {
      const ctx = getCtx();
      const arrayBuffer = base64ToArrayBuffer(dataUrl);
      ctx.decodeAudioData(
        arrayBuffer.slice(0), // slice — decodeAudioData "съедает" буфер
        (decoded) => { customBuffer = decoded; console.log('[claude-sound] custom sound loaded'); },
        (err) => { console.log('[claude-sound] failed to decode custom sound:', err); }
      );
    } catch (e) {
      console.log('[claude-sound] setCustomSound error:', e);
    }
  }

  window.addEventListener('claude-sound-config', (e) => {
    setCustomSound(e.detail && e.detail.dataUrl);
  });
  // на случай если bridge.js уже отправил событие до того как этот скрипт подписался
  window.dispatchEvent(new CustomEvent('claude-sound-request-config'));

  function playDefaultBeep() {
    const ctx = getCtx();
    const now = ctx.currentTime;
    [[880, now, 0.12], [1320, now + 0.13, 0.15]].forEach(([freq, start, dur]) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.4, start + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + dur + 0.02);
    });
  }

  function playSound() {
    try {
      const ctx = getCtx();
      if (customBuffer) {
        const src = ctx.createBufferSource();
        src.buffer = customBuffer;
        const gain = ctx.createGain();
        gain.gain.value = 0.7;
        src.connect(gain);
        gain.connect(ctx.destination);
        src.start(0);
      } else {
        playDefaultBeep();
      }
    } catch (e) {
      console.log('[claude-sound] playSound failed:', e);
    }
  }

  function unlockOnce() {
    getCtx();
    document.removeEventListener('click', unlockOnce);
    document.removeEventListener('keydown', unlockOnce);
  }
  document.addEventListener('click', unlockOnce);
  document.addEventListener('keydown', unlockOnce);

  const origFetch = window.fetch;
  const origLog = console.log;

  window.fetch = function (...args) {
    const promise = origFetch.apply(this, args);

    let url = '';
    try {
      url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
    } catch (e) {}

    const isCompletion = url.includes('/completion');

    if (isCompletion) {
      promise.then((response) => {
        try {
          const clone = response.clone();
          if (!clone.body) return;
          const reader = clone.body.getReader();
          const pump = () => reader.read().then(({ done }) => {
            if (done) {
              playSound();
              return;
            }
            pump();
          }).catch(() => {});
          pump();
        } catch (e) {}
      }).catch(() => {});
    }

    return promise;
  };

  origLog.call(console, '[claude-sound] v4 active (custom sound support)');
})();
