// Мост между chrome.storage (доступен только в isolated world) и content.js (MAIN world).
// MAIN world не имеет доступа к chrome.* API, поэтому передаём данные через CustomEvent.

(function () {
  'use strict';

  function sendConfig(dataUrl) {
    window.dispatchEvent(new CustomEvent('claude-sound-config', {
      detail: { dataUrl: dataUrl || null }
    }));
  }

  function loadAndSend() {
    chrome.storage.local.get(['customSoundDataUrl'], (result) => {
      sendConfig(result.customSoundDataUrl);
    });
  }

  loadAndSend();

  // Если пользователь поменяет звук в попапе, пока страница открыта — подхватываем сразу
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.customSoundDataUrl) {
      sendConfig(changes.customSoundDataUrl.newValue);
    }
  });

  // На случай если MAIN-скрипт подгрузился чуть позже и пропустил первое событие
  window.addEventListener('claude-sound-request-config', loadAndSend);
})();
